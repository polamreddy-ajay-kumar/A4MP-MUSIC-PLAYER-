// Supabase > Project Settings > API. Use the ANON (public) key only. Never the service_role key.
export const CFG={SUPABASE_URL:'https://YOUR-PROJECT.supabase.co',SUPABASE_ANON_KEY:'YOUR_ANON_KEY',
 SOCIAL:{Instagram:'',YouTube:'',Spotify:'',LinkedIn:''},EMAIL:''}; // empty values are hidden
