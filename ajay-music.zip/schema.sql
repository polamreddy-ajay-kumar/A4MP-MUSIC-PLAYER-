-- Run in Supabase > SQL Editor
create table public.songs(
 id uuid primary key default gen_random_uuid(),
 title text not null, artist text not null default 'POLAMREDDY AJAY KUMAR',
 category text not null default 'General', duration int not null default 0,
 audio_path text not null, cover_path text,
 downloadable boolean not null default false, published boolean not null default true,
 created_at timestamptz not null default now());
create table public.admins(user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.songs enable row level security;
alter table public.admins enable row level security;
create function public.is_admin() returns boolean language sql security definer stable set search_path=public
 as $$ select exists(select 1 from public.admins where user_id=auth.uid()) $$;
create policy "read published or admin" on public.songs for select using (published or public.is_admin());
create policy "admin insert" on public.songs for insert with check (public.is_admin());
create policy "admin update" on public.songs for update using (public.is_admin()) with check (public.is_admin());
create policy "admin delete" on public.songs for delete using (public.is_admin());
create policy "self read" on public.admins for select using (user_id=auth.uid());
insert into storage.buckets(id,name,public) values('songs','songs',true) on conflict (id) do nothing;
create policy "songs read" on storage.objects for select using (bucket_id='songs');
create policy "songs admin insert" on storage.objects for insert with check (bucket_id='songs' and public.is_admin());
create policy "songs admin update" on storage.objects for update using (bucket_id='songs' and public.is_admin());
create policy "songs admin delete" on storage.objects for delete using (bucket_id='songs' and public.is_admin());
-- After creating your admin user in Authentication > Users, run:
-- insert into public.admins(user_id) select id from auth.users where email='YOUR_EMAIL';
