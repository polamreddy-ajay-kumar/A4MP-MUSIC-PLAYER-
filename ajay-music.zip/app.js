import {createClient} from 'https://esm.sh/@supabase/supabase-js@2.45.4';
import {CFG} from './config.js';
const ARTIST='POLAMREDDY AJAY KUMAR';
const sb=createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY);
const $=s=>document.querySelector(s),view=$('#view'),au=$('#audio');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pub=(p,dl)=>p?sb.storage.from('songs').getPublicUrl(p,dl?{download:dl}:undefined).data.publicUrl:'';
const fmt=s=>{s=Math.floor(s||0);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},sv=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
let songs=[],queue=[],qi=-1,favs=LS('am_favs',[]),pls=LS('am_pls',[]),isAdmin=false,session=null,q='',cat='All';
let tt;const toast=(m,bad)=>{const t=$('#toast');t.textContent=m;t.className='on'+(bad?' bad':'');clearTimeout(tt);tt=setTimeout(()=>t.className='',3000)};
const cover=(s,cls='')=>s.cover_path?`<div class="cv ${cls}" style="background-image:url('${esc(pub(s.cover_path))}')"></div>`:`<div class="cv ${cls}">${esc(s.title[0]||'♪').toUpperCase()}</div>`;
async function loadSongs(){const {data,error}=await sb.from('songs').select('*').order('created_at',{ascending:false});if(error)throw error;songs=data||[]}
async function loadAuth(){const {data}=await sb.auth.getSession();session=data.session;isAdmin=false;
 if(session){const {data:a}=await sb.from('admins').select('user_id').eq('user_id',session.user.id).maybeSingle();isAdmin=!!a}}
const card=(s,list)=>`<div class="card"><a href="#/song/${s.id}">${cover(s)}<h3>${esc(s.title)}</h3></a><div class="cf"><small>${esc(s.artist)} · ${fmt(s.duration)}</small><button class="pb" data-play="${s.id}" data-list="${list}" aria-label="Play ${esc(s.title)}">▶</button></div></div>`;
const item=(s,list,extra='')=>`<div class="it">${cover(s,'sm')}<div class="gr"><a href="#/song/${s.id}"><b>${esc(s.title)}</b></a><small>${esc(s.artist)} · ${esc(s.category)} · ${fmt(s.duration)}${s.published?'':' · DRAFT'}</small></div>
 <button data-fav="${s.id}" aria-label="Favorite">${favs.includes(s.id)?'♥':'♡'}</button><button class="pb" data-play="${s.id}" data-list="${list}" aria-label="Play">▶</button>${extra}</div>`;
const empty=m=>`<div class="empty">${m}</div>`;
function setMeta(t,d,img){document.title=t;for(const [k,v] of [['description',d],['og:title',t],['og:description',d],['og:image',img||''],['og:url',location.href]]){let e=document.querySelector(`meta[name="${k}"],meta[property="${k}"]`);if(!e){e=document.createElement('meta');e.setAttribute(k.startsWith('og:')?'property':'name',k);document.head.appendChild(e)}e.content=v}}
async function route(){
 const [,r,id]=(location.hash||'#/').split('/');document.querySelectorAll('nav a').forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#/'+(r||'')));
 view.innerHTML='<div class="load">Loading…</div>';
 try{await Promise.all([loadSongs(),loadAuth()])}catch(e){view.innerHTML=`<div class="err">Could not load songs: ${esc(e.message)}<br><br><button onclick="location.reload()">Retry</button></div>`;return}
 setMeta('AJAY MUSIC | Songs by '+ARTIST,'Stream original songs by '+ARTIST+' on AJAY MUSIC.');
 ({'':home,library,song,playlists,admin}[r||''] || home)(id);window.scrollTo(0,0)}
const live=()=>songs.filter(s=>s.published);
function home(){const l=live();view.innerHTML=`<section class="hero"><div class="av">A</div><div><small>ARTIST</small><h1>${ARTIST}</h1><p>Welcome to <b>AJAY MUSIC</b>. Stream my original songs, build playlists and save your favorites.</p><a class="btn pri" href="#/library">Browse all songs</a></div></section>
 <h2>Featured <em>songs</em></h2>${l.length?`<div class="grid">${l.slice(0,6).map(s=>card(s,'home')).join('')}</div>`:empty('No songs have been published yet. Check back soon.')}`}
function library(){const l=live(),cats=['All',...new Set(l.map(s=>s.category))];
 view.innerHTML=`<h2>Song <em>library</em></h2><input type="search" id="q" placeholder="Search title, artist or category" value="${esc(q)}"><div class="chips">${cats.map(c=>`<button class="chip ${c===cat?'on':''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div><div id="res"></div>`;
 const draw=()=>{const f=l.filter(s=>(cat==='All'||s.category===cat)&&(s.title+' '+s.artist+' '+s.category).toLowerCase().includes(q.toLowerCase()));
  $('#res').innerHTML=!l.length?empty('No songs have been published yet.'):f.length?`<div class="grid">${f.map(s=>card(s,'lib')).join('')}</div>`:empty('No songs match your search.');window.__lib=f};
 draw();$('#q').oninput=e=>{q=e.target.value;draw()};
 view.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{cat=b.dataset.cat;library()})}
function song(id){const s=live().find(x=>x.id===id)||(isAdmin&&songs.find(x=>x.id===id));
 if(!s){view.innerHTML=empty('This song does not exist or is not published.<br><br><a class="btn" href="#/library">Back to library</a>');return}
 setMeta(s.title+' | '+ARTIST+' | AJAY MUSIC','Listen to "'+s.title+'" by '+s.artist+' on AJAY MUSIC.',pub(s.cover_path));
 view.innerHTML=`<div class="detail">${cover(s)}<div><small>${esc(s.category)}</small><h1>${esc(s.title)}</h1><p>${esc(s.artist)} · ${fmt(s.duration)}</p><div class="row">
 <button class="btn pri" data-play="${s.id}" data-list="one">▶ Play</button><button class="btn" data-fav="${s.id}">${favs.includes(s.id)?'♥ Favorited':'♡ Favorite'}</button><button class="btn" data-addpl="${s.id}">＋ Playlist</button><button class="btn" data-share="${s.id}">Share</button>
 ${s.downloadable?`<a class="btn" href="${esc(pub(s.audio_path,s.title+'.mp3'))}" download>Download</a>`:''}</div></div></div>`}
function playlists(id){
 const body=pls.length?pls.map((p,i)=>{const ss=p.ids.map(x=>songs.find(s=>s.id===x&&(s.published||isAdmin))).filter(Boolean);
  return `<h2>${esc(p.name)} <small>(${ss.length})</small> <button data-delpl="${i}">Delete</button></h2>${ss.length?`<div class="list">${ss.map(s=>item(s,'pl'+i,`<button data-rmpl="${i}:${s.id}">✕</button>`)).join('')}</div>`:empty('This playlist is empty. Use “＋ Playlist” on a song page.')}`}).join(''):empty('You have no playlists yet. Create one above.');
 const fl=favs.map(x=>live().find(s=>s.id===x)).filter(Boolean);
 view.innerHTML=`<h2>Your <em>playlists</em></h2><form class="row" id="npl"><input type="text" id="pn" placeholder="New playlist name" maxlength="60" required style="flex:1"><button class="btn pri">Create</button></form><small>Playlists and favorites are saved in this browser.</small>${body}<h2><em>Favorites</em></h2>${fl.length?`<div class="list">${fl.map(s=>item(s,'fav')).join('')}</div>`:empty('No favorites yet. Tap ♡ on any song.')}`;
 $('#npl').onsubmit=e=>{e.preventDefault();const n=$('#pn').value.trim();if(!n)return;pls.push({name:n,ids:[]});sv('am_pls',pls);playlists()}}
const listFor=k=>k==='home'?live().slice(0,6):k==='lib'?(window.__lib||live()):k==='fav'?favs.map(x=>live().find(s=>s.id===x)).filter(Boolean):k.startsWith('pl')?pls[+k.slice(2)].ids.map(x=>songs.find(s=>s.id===x)).filter(Boolean):null;
function play(list,i){queue=list;qi=i;const s=queue[qi];au.src=pub(s.audio_path);au.play().catch(e=>toast('Cannot play this song: '+e.message,1));$('#pt').textContent=s.title;$('#pa').textContent=s.artist;$('#pc').outerHTML=cover(s,'sm').replace('class="cv sm"','id="pc" class="cv sm"');
 if('mediaSession'in navigator)navigator.mediaSession.metadata=new MediaMetadata({title:s.title,artist:s.artist,artwork:s.cover_path?[{src:pub(s.cover_path)}]:[]})}
const step=d=>{if(!queue.length)return;play(queue,(qi+d+queue.length)%queue.length)};
$('#pp').onclick=()=>{if(!au.src)return toast('Pick a song first');au.paused?au.play():au.pause()};$('#next').onclick=()=>step(1);$('#prev').onclick=()=>au.currentTime>3?au.currentTime=0:step(-1);
au.onplay=()=>$('#pp').textContent='⏸';au.onpause=()=>$('#pp').textContent='▶';au.onended=()=>step(1);au.onerror=()=>au.src&&toast('Audio failed to load',1);
au.ontimeupdate=()=>{$('#tc').textContent=fmt(au.currentTime);if(au.duration)$('#sk').value=au.currentTime/au.duration*1000};au.onloadedmetadata=()=>$('#td').textContent=fmt(au.duration);
$('#sk').oninput=e=>{if(au.duration)au.currentTime=e.target.value/1000*au.duration};au.volume=.8;$('#vl').oninput=e=>au.volume=e.target.value/100;
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;const d=b.dataset;
 if(d.play){const l=listFor(d.list)||[songs.find(s=>s.id===d.play)];play(l,Math.max(0,l.findIndex(s=>s.id===d.play)))}
 if(d.fav){favs=favs.includes(d.fav)?favs.filter(x=>x!==d.fav):[...favs,d.fav];sv('am_favs',favs);route()}
 if(d.share){const u=location.origin+location.pathname+'#/song/'+d.share;try{navigator.share?await navigator.share({title:'AJAY MUSIC',url:u}):(await navigator.clipboard.writeText(u),toast('Link copied'))}catch{}}
 if(d.addpl){if(!pls.length)return toast('Create a playlist first (Playlists page)',1);const n=prompt('Add to which playlist?\n'+pls.map((p,i)=>(i+1)+'. '+p.name).join('\n'));const p=pls[(+n||0)-1];if(!p)return;if(p.ids.includes(d.addpl))return toast('Already in playlist');p.ids.push(d.addpl);sv('am_pls',pls);toast('Added to '+p.name)}
 if(d.delpl&&confirm('Delete this playlist?')){pls.splice(+d.delpl,1);sv('am_pls',pls);playlists()}
 if(d.rmpl){const [i,id]=d.rmpl.split(':');pls[+i].ids=pls[+i].ids.filter(x=>x!==id);sv('am_pls',pls);playlists()}
 if(d.edit)admin(null,d.edit);
 if(d.del)delSong(d.del)});
async function delSong(id){const s=songs.find(x=>x.id===id);if(!s||!confirm('Delete "'+s.title+'" permanently?'))return;
 const {error}=await sb.from('songs').delete().eq('id',id);if(error)return toast(error.message,1);
 await sb.storage.from('songs').remove([s.audio_path,s.cover_path].filter(Boolean));toast('Deleted');route()}
const upload=async(f,dir)=>{const p=`${dir}/${crypto.randomUUID()}.${f.name.split('.').pop().toLowerCase()}`;const {error}=await sb.storage.from('songs').upload(p,f,{contentType:f.type,cacheControl:'3600'});if(error)throw error;return p};
const dur=f=>new Promise(r=>{const a=new Audio(),u=URL.createObjectURL(f);a.preload='metadata';a.onloadedmetadata=()=>{r(Math.round(a.duration)||0);URL.revokeObjectURL(u)};a.onerror=()=>r(0);a.src=u});
function admin(_,editId){
 if(!session){view.innerHTML=`<h2>Admin <em>login</em></h2><form class="f" id="lf"><label>Email<input type="email" id="em" required autocomplete="username"></label><label>Password<input type="password" id="pw" required autocomplete="current-password"></label><button class="btn pri">Sign in</button><small id="le"></small></form>`;
  $('#lf').onsubmit=async e=>{e.preventDefault();const {error}=await sb.auth.signInWithPassword({email:$('#em').value,password:$('#pw').value});error?$('#le').textContent=error.message:route()};return}
 if(!isAdmin){view.innerHTML=`<div class="err">Signed in as ${esc(session.user.email)}, but this account is not an admin.<br><br><button id="so">Sign out</button></div>`;$('#so').onclick=async()=>{await sb.auth.signOut();route()};return}
 const s=songs.find(x=>x.id===editId)||{};
 view.innerHTML=`<div class="row" style="justify-content:space-between"><h2 style="margin:0">${s.id?'Edit':'Add'} <em>song</em></h2><button id="so">Sign out</button></div>
 <form class="f" id="sf" style="margin-top:16px"><label>Title<input type="text" id="t" required value="${esc(s.title)}"></label><label>Artist<input type="text" id="a" required value="${esc(s.artist||ARTIST)}"></label><label>Category<input type="text" id="c" required value="${esc(s.category||'')}" placeholder="e.g. Devotional, Pop, Folk"></label>
 <label>MP3 file ${s.id?'(leave empty to keep current)':''}<input type="file" id="af" accept="audio/mpeg,.mp3" ${s.id?'':'required'}></label><label>Cover image ${s.id?'(leave empty to keep current)':''}<input type="file" id="cf" accept="image/*"></label>
 <label class="ck"><input type="checkbox" id="dl" ${s.downloadable?'checked':''}> Allow download</label><label class="ck"><input type="checkbox" id="pb" ${s.published===false?'':'checked'}> Published (visible to public)</label>
 <div class="row"><button class="btn pri" id="sb">${s.id?'Save changes':'Upload song'}</button>${s.id?'<a class="btn" href="#/admin">Cancel</a>':''}</div><small id="st"></small></form>
 <h2>All <em>songs</em> (${songs.length})</h2>${songs.length?`<div class="list">${songs.map(x=>item(x,'none',`<button data-edit="${x.id}">Edit</button><button data-del="${x.id}">Delete</button>`)).join('')}</div>`:empty('No songs yet. Upload your first song above.')}`;
 $('#so').onclick=async()=>{await sb.auth.signOut();route()};
 $('#sf').onsubmit=async e=>{e.preventDefault();const btn=$('#sb'),st=$('#st');btn.disabled=true;const old=[];
  try{const row={title:$('#t').value.trim(),artist:$('#a').value.trim(),category:$('#c').value.trim(),downloadable:$('#dl').checked,published:$('#pb').checked};
   const af=$('#af').files[0],cf=$('#cf').files[0];
   if(af){st.textContent='Uploading MP3…';row.duration=await dur(af);row.audio_path=await upload(af,'audio');if(s.audio_path)old.push(s.audio_path)}
   if(cf){st.textContent='Uploading cover…';row.cover_path=await upload(cf,'covers');if(s.cover_path)old.push(s.cover_path)}
   st.textContent='Saving…';const {error}=s.id?await sb.from('songs').update(row).eq('id',s.id):await sb.from('songs').insert(row);if(error)throw error;
   if(old.length)await sb.storage.from('songs').remove(old);toast('Saved');location.hash='#/admin';route()}
  catch(er){st.textContent='Error: '+er.message;toast(er.message,1);btn.disabled=false}}}
const soc=Object.entries(CFG.SOCIAL||{}).filter(([,u])=>u);
$('#foot').innerHTML=`<div><b style="color:var(--g)">AJAY MUSIC</b><br>© ${new Date().getFullYear()} ${ARTIST}</div><div>${soc.map(([n,u])=>`<a href="${esc(u)}" target="_blank" rel="noopener">${esc(n)}</a>`).join(' · ')}${CFG.EMAIL?` · <a href="mailto:${esc(CFG.EMAIL)}">${esc(CFG.EMAIL)}</a>`:''}</div>`;
addEventListener('hashchange',route);sb.auth.onAuthStateChange((ev)=>{if(ev==='SIGNED_OUT')route()});route();
